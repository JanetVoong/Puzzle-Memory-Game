let round = 1
Score = [0,0,0] // stores scores for each player
P = [] // stores pattern

var SHAPE1;
var SHAPE2;
var SHAPE3;
var SHAPE4;
var SHAPE5;
var Tiles = [SHAPE1,SHAPE2,SHAPE3,SHAPE4,SHAPE5]

// stores player key inputs
Player1 = []
Player2 = []
Player3 = []
seconds = 10 // timer

function preload(){
  // key for players
  theKey = loadImage('/assets/key.png')
  // shapes for pattern
  circle = loadImage('/assets/blueCircle.png')
  diamond = loadImage('/assets/orangeDiamond.png')
  triangle = loadImage('/assets/redTriangle.png')
  // numbers
  zero = loadImage('/assets/zero.png')
  one = loadImage('/assets/one.png')
  two = loadImage('/assets/two.png')
  three = loadImage('/assets/three.png')
  four = loadImage('/assets/four.png')
  five = loadImage('/assets/five.png')
  // winner and loser icons
  trophy = loadImage('/assets/trophy.png')
  skull = loadImage('/assets/skull.png')
}

class Shape {
  constructor(n,x,y){ // creates attributes
    self.number = n // n is the number used to represent a shape
    self.x = x
    self.y = y
    // indicates which keys would represent which shapes
    if (self.number == 0){
      self.texture = circle
    } if (self.number == 1){
      self.texture = diamond
    } if (self.number == 2){
      self.texture = triangle
    }
    // displays the pattern with equal
    self.shape = image(self.texture,self.x,self.y,self.texture.width/2,self.texture.height/2) // 1 is the size of the box
  }
  delete(){
    self.shape.remove
  }
}
class number {
  constructor(n,x,y){ // creates attributes
    scoreTexture = [zero, one, two, three, four, five]
    self.number = n // n is the number used to represent shape
    self.shape = createSprite(x,y,1)
    self.shape.loadImage(scoreTexture[self.number]) // loads image according to index
  }
}

// loads the winner
function Winner(){
  if ((Score[0] > Score[1]) && (Score[0]) > Score[2]){
    console.log("Player1 wins")
    image(one,150,100) // indicates that player 1 has won
    image(trophy,150,300) //put image of winner
    image(two,350,100)
    image(skull,350,300)
    image(three,550,100)
    image(skull,550,300)
  } else if ((Score[1] > Score[0]) && (Score[1]) > Score[2]){
    console.log("Player2 wins")
    image(one,150,100)
    image(skull,150,300)
    image(two,350,100)
    image(trophy,350,300)
    image(three,550,100)
    image(skull,550,300)
  } else if ((Score[2] > Score[0]) && (Score[2]) > Score[1]){
    console.log("Player3 wins")
    image(one,150,100)
    image(skull,150,300)
    image(two,350,100)
    image(skull,350,300)
    image(three,550,100)
    image(trophy,550,300)
  } else {
    console.log("No winner")
    image(one,150,100)
    image(skull,150,300)
    image(two,350,100)
    image(skull,350,300)
    image(three,550,100)
    image(skull,550,300)
  }
}

// randomly generates the pattern
function pattern(round){
  P = []
  for (i = 0; i < round; i+=1){
    Item = ceil(3*Math.random())-1 //random goes from 0-1 using decimals , 4 makes the numbers bigger, ceil always rounds up, -1 because indexes start at 0
    P.push(Item)
  }
}

// clears scores
function clearData(){
  Player1 = []
  Player2 = []
  Player3 = []
}


function drawShapes(P,Scores){
  for(i=0; i< P.length; i+=1){
    Tiles[i] = (new Shape(P[i],(i*100)+100,100)).shape
    //Tiles[i].shape.remove
    //X.shape.remove
  }
}
function keyHeld(){
  if (keyIsDown(65)){
    Player1.push(0)
  } if (keyIsDown(83)){
    Player1.push(1)
  } if (keyIsDown(68)){
    Player1.push(2)
  }
  if (keyIsDown(86)){
    Player2.push(0)
  } if (keyIsDown(66)){
    Player2.push(1)
  } if (keyIsDown(78)){
    Player2.push(2)
  }
  if (keyIsDown(73)){
    Player3.push(0)
  } if (keyIsDown(79)){
    Player3.push(1)
  } if (keyIsDown(80)){
    Player3.push(2)
  }
}

function comparePattern(P){
  Players = [Player1,Player2,Player3]
  console.log(Player1,Player2,Player3)
  console.log(P)
  for (i=0;i<Players.length;i+=1){
    console.log(round)
    if (Players[i].length == round-1){ // checks lists is as long as round
      if (Players[i].toString() == P.toString() ){
        Score[i] += 1
      }
    }
  }
}

function setup(){
  createCanvas(800, 500);
}

function draw(){
  if (round == 6){
    background(245);
    Winner()
  } else {
  background(245);
  image(theKey,165,425,50,50)
  image(circle,265,425,50,50)
  image(diamond,365,425,50,50)
  image(triangle,475,425,50,50)
    image(theKey,565,425,50,50)
  if ((round == 1) && (frameCount == 1)){
    pattern(round)
    round+=1
  }
  if (frameCount %(30*seconds) == 0){
    if (round != 6){
      pattern(round)
      clearData()
      round+=1;
      console.log("")
    }
    }
  drawShapes(P,Score)
  //load shape
  if (((frameCount-8) % 8 == 0) || ((frameCount-15) % 15 == 0)){
  keyHeld()
}

comparePattern(P)
  //keypress check
  //timer
  //round+=1
}
}
